import java.awt.event.*;
import javax.swing.*;
public class Main {
    public JFrame f;
    public static void main(String[] args) {
        Main myMain;
        myMain= new Main();

    }
    public Main(){
        setupGraphics();
    }
    public String reverese(String in){

        String backwords="";
        char[] myChar = in.toCharArray();
        for (int i = myChar.length - 1; i >= 0; i--) {
            backwords= backwords+myChar[i];
            //System.out.print(try1[i]);
        }
        return (backwords);
    }
    public void setupGraphics(){
         f=new JFrame("Button Example");
        JTextField input=new JTextField();
        input.setBounds(50,50, 150,20);

        JTextField output=new JTextField();
        output.setBounds(50,100, 150,20);

        JButton b=new JButton("Click Here");
        b.setBounds(50,150,95,30);
        b.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String hold = input.getText();

                output.setText(reverese(hold));

            }
        });
        f.add(b);
        f.add(input);
        f.add(output);
        f.setSize(400,400);
        f.setLayout(null);
        f.setVisible(true);
    }
}  